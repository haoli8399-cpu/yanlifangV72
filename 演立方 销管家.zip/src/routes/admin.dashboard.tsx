import { createFileRoute } from "@tanstack/react-router";
import { Card, Col, Progress, Row, Space, Statistic, Table, Tag, Typography } from "antd";
import { ArrowDownOutlined, ArrowUpOutlined, RobotOutlined } from "@ant-design/icons";
import { funnelData, platformKpi, trend30d } from "../shared/mock/admin";
import { yuan } from "../shared/components/formatters";

export const Route = createFileRoute("/admin/dashboard")({
  head: () => ({ meta: [{ title: "平台大盘 · 演立方 Admin" }] }),
  component: Dashboard,
});

function Dashboard() {
  const k = platformKpi;
  const maxGmv = Math.max(...trend30d.map((d) => d.gmv));
  const maxFunnel = funnelData[0].value;

  return (
    <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
      <Space direction="vertical" size={2}>
        <Typography.Title level={3} style={{ margin: 0 }}>平台大盘</Typography.Title>
        <Typography.Text type="secondary">GMV、转化漏斗、AI 采纳率与团队表现 · 数据每 5 分钟刷新</Typography.Text>
      </Space>

      <Row gutter={16}>
        <Col span={6}>
          <Card>
            <Statistic title="本月成交额 (GMV)" value={k.monthGmv} formatter={(v) => yuan(Number(v))} valueStyle={{ color: "#6E59F5" }} />
            <Tag color="green" style={{ marginTop: 8 }}><ArrowUpOutlined /> {k.monthGmvDelta}% vs 上月</Tag>
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic title="本月成交单数" value={k.monthWins} suffix="单" valueStyle={{ color: "#00B96B" }} />
            <Tag color="green" style={{ marginTop: 8 }}><ArrowUpOutlined /> +{k.monthWinsDelta} vs 上月</Tag>
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic title="平均客单价" value={k.avgOrder} formatter={(v) => yuan(Number(v))} valueStyle={{ color: "#1677FF" }} />
            <Tag color="green" style={{ marginTop: 8 }}><ArrowUpOutlined /> {k.avgOrderDelta}%</Tag>
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic title="AI 方案采纳率" value={k.aiAdoptRate} suffix="%" prefix={<RobotOutlined />} valueStyle={{ color: "#FA8C16" }} />
            <Tag color="green" style={{ marginTop: 8 }}><ArrowUpOutlined /> +{k.aiAdoptDelta}pp</Tag>
          </Card>
        </Col>
      </Row>

      <Row gutter={16}>
        <Col span={16}>
          <Card title="近 30 天 GMV 趋势" extra={<Typography.Text type="secondary">单位：元</Typography.Text>}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 200, padding: "8px 0" }}>
              {trend30d.map((d) => (
                <div key={d.date} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }} title={`${d.date}  ¥${d.gmv.toLocaleString()}`}>
                  <div style={{ width: "100%", height: `${(d.gmv / maxGmv) * 170}px`, background: "linear-gradient(180deg, #6E59F5, #4B34D1)", borderRadius: 4 }} />
                </div>
              ))}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#8B92A8", marginTop: 4 }}>
              <span>{trend30d[0].date}</span>
              <span>{trend30d[Math.floor(trend30d.length / 2)].date}</span>
              <span>{trend30d[trend30d.length - 1].date}</span>
            </div>
          </Card>
        </Col>
        <Col span={8}>
          <Card title="转化漏斗（近 30 天）">
            <Space direction="vertical" size={14} style={{ width: "100%" }}>
              {funnelData.map((f, i) => {
                const pct = Math.round((f.value / maxFunnel) * 100);
                const rate = i === 0 ? 100 : Math.round((f.value / funnelData[i - 1].value) * 100);
                return (
                  <div key={f.stage}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                      <span>{f.stage}</span>
                      <span>
                        <b style={{ fontVariantNumeric: "tabular-nums" }}>{f.value}</b>
                        {i > 0 && <Tag color={rate > 60 ? "green" : rate > 40 ? "orange" : "red"} style={{ marginLeft: 8 }}>{rate}%</Tag>}
                      </span>
                    </div>
                    <Progress percent={pct} showInfo={false} strokeColor="#6E59F5" />
                  </div>
                );
              })}
            </Space>
          </Card>
        </Col>
      </Row>

      <Row gutter={16}>
        <Col span={8}>
          <Card title="关键健康指标">
            <Space direction="vertical" size={14} style={{ width: "100%" }}>
              <MiniGauge label="报价率" value={k.quotationRate} color="#1677FF" />
              <MiniGauge label="成交率" value={k.winRate} color="#00B96B" />
              <MiniGauge label="AI 采纳率" value={k.aiAdoptRate} color="#6E59F5" />
            </Space>
          </Card>
        </Col>
        <Col span={8}>
          <Card title="平台规模">
            <Row gutter={16}>
              <Col span={12}><Statistic title="活跃客户" value={k.activeCustomers} /></Col>
              <Col span={12}><Statistic title="在售艺人" value={k.activeArtists} /></Col>
            </Row>
            <Typography.Paragraph type="secondary" style={{ marginTop: 12, marginBottom: 0, fontSize: 12 }}>
              过去 30 天有成交或询单行为的口径；含 KA 与自然流量。
            </Typography.Paragraph>
          </Card>
        </Col>
        <Col span={8}>
          <Card title="销售 Leaderboard（本月）">
            <Table
              size="small"
              pagination={false}
              rowKey="name"
              columns={[
                { title: "运营", dataIndex: "name" },
                { title: "成交", dataIndex: "wins", width: 70 },
                { title: "GMV", dataIndex: "gmv", render: (v: number) => yuan(v) },
              ]}
              dataSource={[
                { name: "张运营", wins: 18, gmv: 1420000 },
                { name: "李运营", wins: 15, gmv: 1180000 },
                { name: "王运营", wins: 11, gmv: 860000 },
              ]}
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
}

function MiniGauge({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
        <span>{label}</span>
        <b style={{ fontVariantNumeric: "tabular-nums", color }}>{value}%</b>
      </div>
      <Progress percent={value} showInfo={false} strokeColor={color} />
    </div>
  );
}

// keep icon import used
void ArrowDownOutlined;