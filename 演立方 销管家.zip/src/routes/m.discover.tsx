import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Card, Input, Segmented, Space, Tag, Typography } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import { useMemo, useState } from "react";
import { solutions } from "../shared/mock/data";
import { yuan } from "../shared/components/formatters";

export const Route = createFileRoute("/m/discover")({
  component: MDiscover,
});

const TIERS = ["全部", "经济方案", "推荐方案", "升级方案"] as const;
type Tier = (typeof TIERS)[number];

function MDiscover() {
  const nav = useNavigate();
  const [tier, setTier] = useState<Tier>("全部");
  const [kw, setKw] = useState("");

  const list = useMemo(
    () =>
      solutions.filter(
        (s) =>
          (tier === "全部" || s.tier === tier) &&
          (!kw || s.name.includes(kw) || s.applicableScenes.some((sc) => sc.includes(kw))),
      ),
    [tier, kw],
  );

  return (
    <div>
      <div
        style={{
          padding: "20px 20px 12px",
          background: "#fff",
          borderBottom: "1px solid #EEF0F5",
          position: "sticky",
          top: 0,
          zIndex: 5,
        }}
      >
        <Typography.Title level={4} style={{ margin: 0 }}>找方案</Typography.Title>
        <Input
          prefix={<SearchOutlined style={{ color: "#8B92A8" }} />}
          placeholder="搜索方案 / 场景"
          value={kw}
          onChange={(e) => setKw(e.target.value)}
          style={{ marginTop: 12, borderRadius: 10, background: "#F5F6FA" }}
          variant="filled"
        />
        <div style={{ marginTop: 10 }}>
          <Segmented
            block
            size="small"
            value={tier}
            onChange={(v) => setTier(v as Tier)}
            options={TIERS.slice()}
          />
        </div>
      </div>

      <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
        {list.length === 0 && (
          <div style={{ textAlign: "center", padding: 40, color: "#8B92A8" }}>暂无匹配方案</div>
        )}
        {list.map((s) => (
          <Card
            key={s.id}
            hoverable
            styles={{ body: { padding: 14 } }}
            style={{ borderRadius: 14 }}
            onClick={() => nav({ to: "/m/submit", search: { q: `我想办一场${s.applicableScenes[0] ?? "年会"}` } } as never)}
          >
            <Space wrap size={6}>
              <Tag color="purple" style={{ borderRadius: 4 }}>{s.tier}</Tag>
              <Tag style={{ borderRadius: 4 }}>SKU {s.sku}</Tag>
            </Space>
            <div style={{ fontSize: 15, fontWeight: 700, marginTop: 8 }}>{s.name}</div>
            <div style={{ fontSize: 11, color: "#8B92A8", marginTop: 4 }}>
              {s.durationMinutes} 分钟 · 适合 {s.headcountRange[0]}-{s.headcountRange[1]} 人 · {s.applicableScenes.join("/")}
            </div>
            <div style={{ marginTop: 8, fontSize: 12, color: "#5B6178", lineHeight: 1.6 }}>
              {s.items.slice(0, 3).map((i) => i.artistName).join(" · ")}
            </div>
            <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
              <div>
                <div style={{ fontSize: 11, color: "#8B92A8" }}>方案价</div>
                <div style={{ fontSize: 20, fontWeight: 800, color: "#6E59F5" }}>{yuan(s.price)}</div>
              </div>
              <Tag color="warning" style={{ borderRadius: 4 }}>推荐 {s.recommendScore}</Tag>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}