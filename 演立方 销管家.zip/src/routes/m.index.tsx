import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Card, Input, Space, Tag, Typography } from "antd";
import { RobotFilled, ArrowRightOutlined, FireFilled } from "@ant-design/icons";
import { useState } from "react";
import { solutions } from "../shared/mock/data";
import { yuan } from "../shared/components/formatters";

export const Route = createFileRoute("/m/")({
  component: MHome,
});

const SCENES = ["年会", "团建", "客户答谢", "商场活动", "发布会", "婚礼"];

function MHome() {
  const nav = useNavigate();
  const [text, setText] = useState("");

  const goSubmit = (q?: string) =>
    nav({ to: "/m/submit", search: q ? { q } : undefined } as never);

  return (
    <div>
      {/* Hero */}
      <div
        style={{
          padding: "40px 20px 28px",
          background:
            "radial-gradient(600px 200px at 100% 0%, rgba(255,255,255,.25), transparent), linear-gradient(160deg,#6E59F5,#4B34D1)",
          color: "#fff",
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <Space size={10} align="center">
          <RobotFilled style={{ fontSize: 22 }} />
          <div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>AI 商演经纪人</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>快速匹配演出方案 · 15 分钟拿到报价</div>
          </div>
        </Space>

        <div
          onClick={() => goSubmit()}
          style={{
            marginTop: 20,
            background: "#fff",
            borderRadius: 14,
            padding: "14px 16px",
            display: "flex",
            alignItems: "center",
            gap: 8,
            color: "#8B92A8",
            cursor: "pointer",
          }}
        >
          <Input
            variant="borderless"
            placeholder="描述你的演出需求... 可粘贴微信聊天"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onPressEnter={() => text && goSubmit(text)}
            style={{ flex: 1, padding: 0 }}
          />
          <div
            onClick={(e) => { e.stopPropagation(); goSubmit(text || undefined); }}
            style={{
              background: "#6E59F5",
              color: "#fff",
              borderRadius: 10,
              padding: "6px 12px",
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            发送 <ArrowRightOutlined />
          </div>
        </div>
      </div>

      {/* Scene chips */}
      <div style={{ padding: "20px 20px 8px" }}>
        <Typography.Text strong style={{ fontSize: 14 }}>
          你想办什么活动？
        </Typography.Text>
        <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8 }}>
          {SCENES.map((s) => (
            <Tag
              key={s}
              onClick={() => goSubmit(`我想办一场${s}`)}
              style={{
                padding: "8px 14px",
                borderRadius: 20,
                margin: 0,
                fontSize: 13,
                background: "#fff",
                border: "1px solid #E7EAF2",
                cursor: "pointer",
              }}
            >
              {s}
            </Tag>
          ))}
        </div>
      </div>

      {/* Hot solutions */}
      <div style={{ padding: "20px" }}>
        <Space style={{ justifyContent: "space-between", width: "100%" }}>
          <Typography.Text strong style={{ fontSize: 14 }}>
            <FireFilled style={{ color: "#FA541C", marginRight: 6 }} />
            热门方案
          </Typography.Text>
          <Typography.Link
            onClick={() => nav({ to: "/m/discover" })}
            style={{ fontSize: 12, color: "#6E59F5" }}
          >
            全部 <ArrowRightOutlined />
          </Typography.Link>
        </Space>

        <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 12 }}>
          {solutions.slice(0, 3).map((s) => (
            <Card
              key={s.id}
              hoverable
              styles={{ body: { padding: 14 } }}
              style={{ borderRadius: 14 }}
              onClick={() => nav({ to: "/m/discover" })}
            >
              <Space align="start" style={{ width: "100%", justifyContent: "space-between" }}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <Tag color="purple" style={{ borderRadius: 4, marginBottom: 6 }}>{s.tier}</Tag>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: "#8B92A8", marginTop: 4 }}>
                    {s.durationMinutes} 分钟 · 适合 {s.headcountRange[0]}-{s.headcountRange[1]} 人
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 18, fontWeight: 800, color: "#6E59F5" }}>{yuan(s.price)}</div>
                  <div style={{ fontSize: 10, color: "#8B92A8" }}>推荐 {s.recommendScore}</div>
                </div>
              </Space>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent deals */}
      <div style={{ padding: "0 20px 20px" }}>
        <Typography.Text strong style={{ fontSize: 14 }}>最近成交案例</Typography.Text>
        <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
          {[
            { title: "字节跳动 · 300人年会", tag: "脱口秀", price: 180000 },
            { title: "小红书 · 200人团建", tag: "即兴喜剧", price: 88000 },
            { title: "SHEIN · 500人发布会", tag: "魔术+脱口秀", price: 260000 },
          ].map((d) => (
            <div
              key={d.title}
              style={{
                background: "#fff",
                borderRadius: 12,
                padding: "12px 14px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{d.title}</div>
                <Tag color="green" style={{ marginTop: 4, borderRadius: 4 }}>{d.tag}</Tag>
              </div>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#00B96B" }}>{yuan(d.price)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}