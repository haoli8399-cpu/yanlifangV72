import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Badge, Empty, List, Segmented, Space, Tag, Typography } from "antd";
import { BellFilled, RobotFilled } from "@ant-design/icons";
import { useMemo, useState } from "react";
import { notifications as seed, type AppNotification } from "../shared/mock/messages";

export const Route = createFileRoute("/m/messages")({
  component: MMessages,
});

const TABS = ["全部", "系统", "报价", "AI提醒", "客服"] as const;
type Tab = (typeof TABS)[number];

const typeColor: Record<AppNotification["type"], string> = {
  系统: "default",
  报价: "purple",
  AI提醒: "geekblue",
  客服: "orange",
};

function timeAgo(iso: string) {
  const min = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (min < 60) return `${min} 分钟前`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} 小时前`;
  return `${Math.floor(h / 24)} 天前`;
}

function MMessages() {
  const nav = useNavigate();
  const [list, setList] = useState(seed);
  const [tab, setTab] = useState<Tab>("全部");
  const filtered = useMemo(
    () => (tab === "全部" ? list : list.filter((n) => n.type === tab)),
    [list, tab],
  );
  const unread = list.filter((n) => !n.read).length;

  return (
    <div>
      <div style={{ padding: "20px 20px 12px", background: "#fff", borderBottom: "1px solid #EEF0F5" }}>
        <Typography.Title level={4} style={{ margin: 0 }}>
          消息 {unread > 0 && <Badge count={unread} style={{ marginLeft: 8, background: "#F5222D" }} />}
        </Typography.Title>
        <div style={{ marginTop: 12 }}>
          <Segmented block size="small" value={tab} onChange={(v) => setTab(v as Tab)} options={TABS.slice()} />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div style={{ padding: 40 }}><Empty description="暂无消息" /></div>
      ) : (
        <List
          style={{ background: "#fff", margin: 12, borderRadius: 12, overflow: "hidden" }}
          dataSource={filtered}
          renderItem={(n) => (
            <List.Item
              style={{ padding: "14px 16px", background: n.read ? "#fff" : "#FAF9FF", cursor: "pointer" }}
              onClick={() => {
                setList((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
                if (n.link) nav({ to: n.link.to as never, params: n.link.params as never });
              }}
            >
              <List.Item.Meta
                avatar={
                  <Badge dot={!n.read}>
                    <div style={{
                      width: 34, height: 34, borderRadius: 10,
                      background: n.type === "AI提醒" ? "#EEE7FF" : "#F5F6FA",
                      color: "#6E59F5", display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      {n.type === "AI提醒" ? <RobotFilled /> : <BellFilled />}
                    </div>
                  </Badge>
                }
                title={
                  <Space size={6}>
                    <Tag color={typeColor[n.type]} style={{ borderRadius: 4, margin: 0 }}>{n.type}</Tag>
                    <span style={{ fontSize: 13, fontWeight: n.read ? 500 : 700 }}>{n.title}</span>
                  </Space>
                }
                description={
                  <div>
                    <div style={{ fontSize: 12, color: "#5B6178", lineHeight: 1.6 }}>{n.body}</div>
                    <div style={{ fontSize: 11, color: "#8B92A8", marginTop: 4 }}>{timeAgo(n.createdAt)}</div>
                  </div>
                }
              />
            </List.Item>
          )}
        />
      )}
    </div>
  );
}