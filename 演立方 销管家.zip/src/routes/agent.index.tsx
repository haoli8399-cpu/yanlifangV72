import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Button, Card, Col, Input, Row, Space, Tag, Typography } from "antd";
import { ArrowRightOutlined, RobotFilled, SendOutlined } from "@ant-design/icons";
import { useState } from "react";
import { opportunities, scenarioQuickPicks, solutions } from "../shared/mock/data";
import { SolutionCard } from "../shared/components/SolutionCard";
import { StatusTag } from "../shared/components/StatusTag";
import { relativeTime, wan } from "../shared/components/formatters";

export const Route = createFileRoute("/agent/")({
  component: AgentHome,
});

function AgentHome() {
  const nav = useNavigate();
  const [input, setInput] = useState("");

  const go = (text: string) => {
    nav({ to: "/agent/assistant", search: { q: text } as never });
  };

  const recentRequests = opportunities.slice(0, 4);

  return (
    <div style={{ maxWidth: 1280, margin: "0 auto" }}>
      {/* AI 商演经纪人 · Hero */}
      <Card
        style={{
          borderRadius: 20,
          background: "linear-gradient(135deg, #1B1550 0%, #4B34D1 45%, #6E59F5 100%)",
          border: "none",
          color: "#fff",
          overflow: "hidden",
        }}
        styles={{ body: { padding: 40 } }}
      >
        <Space size={12}>
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              background: "rgba(255,255,255,0.15)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 22,
            }}
          >
            <RobotFilled />
          </div>
          <div>
            <div style={{ fontSize: 12, letterSpacing: 1, color: "rgba(255,255,255,.7)" }}>AI 商演经纪人</div>
            <div style={{ fontSize: 22, fontWeight: 700 }}>告诉我您的活动需求</div>
          </div>
        </Space>

        <div style={{ marginTop: 24, display: "flex", gap: 12 }}>
          <Input
            size="large"
            placeholder="例如：公司300人年会，需要一场脱口秀"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onPressEnter={() => input.trim() && go(input.trim())}
            style={{
              flex: 1,
              height: 56,
              borderRadius: 12,
              fontSize: 15,
              border: "1px solid rgba(255,255,255,0.15)",
              background: "rgba(255,255,255,0.08)",
              color: "#fff",
            }}
            styles={{
              input: { background: "transparent", color: "#fff" },
            }}
          />
          <Button
            size="large"
            type="primary"
            icon={<SendOutlined />}
            style={{ height: 56, minWidth: 130, background: "#00B96B", borderColor: "#00B96B", fontSize: 15 }}
            onClick={() => input.trim() && go(input.trim())}
          >
            让 AI 推荐
          </Button>
        </div>

        <div style={{ marginTop: 24 }}>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,.7)", marginBottom: 10 }}>热门场景 · 一键开始</div>
          <Space wrap size={10}>
            {scenarioQuickPicks.map((s) => (
              <Button
                key={s.key}
                size="large"
                onClick={() => go(`我们计划办一场${s.label}，${s.desc}`)}
                style={{
                  height: 44,
                  background: "rgba(255,255,255,0.1)",
                  border: "1px solid rgba(255,255,255,0.18)",
                  color: "#fff",
                  borderRadius: 10,
                }}
              >
                {s.label} · <span style={{ color: "rgba(255,255,255,.65)", fontSize: 12 }}>{s.desc}</span>
              </Button>
            ))}
          </Space>
        </div>
      </Card>

      {/* 推荐方案 */}
      <div style={{ marginTop: 32, marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Typography.Title level={4} style={{ margin: 0 }}>
          为你推荐的方案
        </Typography.Title>
        <Button type="link" onClick={() => nav({ to: "/agent/solutions" })}>
          浏览全部方案 <ArrowRightOutlined />
        </Button>
      </div>
      <Row gutter={16}>
        {solutions.slice(0, 3).map((s, i) => (
          <Col key={s.id} xs={24} md={8}>
            <SolutionCard
              solution={s}
              highlight={i === 1}
              onGetQuote={() => nav({ to: "/agent/quotations/$id", params: { id: "q1" } })}
              onView={() => nav({ to: "/agent/solutions" })}
            />
          </Col>
        ))}
      </Row>

      {/* 最近需求 */}
      <div style={{ marginTop: 32, marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Typography.Title level={4} style={{ margin: 0 }}>
          最近需求
        </Typography.Title>
        <Button type="link" onClick={() => nav({ to: "/agent/requests" })}>
          查看全部 <ArrowRightOutlined />
        </Button>
      </div>
      <Row gutter={[16, 16]}>
        {recentRequests.map((o) => (
          <Col key={o.id} xs={24} md={12} lg={6}>
            <Card
              hoverable
              onClick={() => nav({ to: "/agent/requests" })}
              styles={{ body: { padding: 18 } }}
              style={{ borderRadius: 12 }}
            >
              <Space direction="vertical" size={8} style={{ width: "100%" }}>
                <Space style={{ width: "100%", justifyContent: "space-between" }}>
                  <Tag color="purple" style={{ borderRadius: 4, margin: 0 }}>
                    {o.code}
                  </Tag>
                  <StatusTag status={o.requestStatus} />
                </Space>
                <Typography.Text strong>{o.event.type} · {o.event.scene}</Typography.Text>
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                  {o.event.date} · {o.event.headcount}人 · 预算 {wan(o.event.budget)}
                </Typography.Text>
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                  最近更新 · {relativeTime(o.lastFollowUpAt)}
                </Typography.Text>
              </Space>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
}