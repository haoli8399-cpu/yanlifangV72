import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Avatar, Card, List, Space, Tag, Typography } from "antd";
import {
  FileTextOutlined,
  HeartFilled,
  SettingOutlined,
  RightOutlined,
  ShopOutlined,
  CustomerServiceOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import { currentUser, quotations } from "../shared/mock/data";

export const Route = createFileRoute("/m/me")({
  component: MMe,
});

function MMe() {
  const nav = useNavigate();

  const menu = [
    { icon: <FileTextOutlined />, label: "我的订单", extra: `${quotations.length} 单`, to: "/agent/requests" },
    { icon: <HeartFilled />, label: "收藏方案", extra: "3 条", to: "/m/discover" },
    { icon: <ShopOutlined />, label: "企业信息", extra: currentUser.companyName, to: "/m/me" },
    { icon: <CustomerServiceOutlined />, label: "联系客服", extra: "在线", to: "/m/messages" },
    { icon: <SettingOutlined />, label: "沟通偏好设置", extra: "松弛感喜剧", to: "/m/me" },
    { icon: <LogoutOutlined />, label: "退出登录", to: "/agent/login" },
  ];

  return (
    <div>
      <div style={{
        padding: "36px 20px 40px",
        background: "linear-gradient(160deg,#6E59F5,#4B34D1)",
        color: "#fff",
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
      }}>
        <Space size={14}>
          <Avatar size={56} style={{ background: currentUser.avatarColor, fontSize: 22, fontWeight: 700 }}>
            {currentUser.userName.slice(0, 1)}
          </Avatar>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{currentUser.userName}</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>{currentUser.role} · {currentUser.companyName}</div>
            <Tag color="gold" style={{ marginTop: 6, borderRadius: 4 }}>VIP 客户</Tag>
          </div>
        </Space>
      </div>

      <div style={{ padding: "16px", display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>
        {[
          { v: quotations.length, l: "历史报价" },
          { v: 3, l: "已成交" },
          { v: 5, l: "收藏方案" },
        ].map((s) => (
          <Card key={s.l} styles={{ body: { padding: 14 } }} style={{ borderRadius: 12, textAlign: "center" }}>
            <div style={{ fontSize: 20, fontWeight: 800, color: "#6E59F5" }}>{s.v}</div>
            <div style={{ fontSize: 11, color: "#8B92A8", marginTop: 2 }}>{s.l}</div>
          </Card>
        ))}
      </div>

      <Card style={{ margin: "0 12px 20px", borderRadius: 12 }} styles={{ body: { padding: 0 } }}>
        <List
          dataSource={menu}
          renderItem={(m) => (
            <List.Item style={{ padding: "14px 16px", cursor: "pointer" }} onClick={() => nav({ to: m.to as never })}>
              <List.Item.Meta
                avatar={
                  <div style={{
                    width: 32, height: 32, borderRadius: 10, background: "#F5F0FF",
                    color: "#6E59F5", display: "flex", alignItems: "center", justifyContent: "center",
                  }}>{m.icon}</div>
                }
                title={<span style={{ fontSize: 14 }}>{m.label}</span>}
              />
              <Space>
                {m.extra && <Typography.Text type="secondary" style={{ fontSize: 12 }}>{m.extra}</Typography.Text>}
                <RightOutlined style={{ color: "#C4C8D4", fontSize: 12 }} />
              </Space>
            </List.Item>
          )}
        />
      </Card>

      <div style={{ textAlign: "center", padding: "0 0 24px", color: "#8B92A8", fontSize: 11 }}>
        演立方 · V3.3.3
      </div>
    </div>
  );
}