import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Button, Card, Form, Input, Segmented, Space, Typography, message } from "antd";
import { MobileOutlined, SafetyCertificateOutlined } from "@ant-design/icons";
import { useState } from "react";

export const Route = createFileRoute("/agent/login")({
  component: AgentLogin,
});

function AgentLogin() {
  const nav = useNavigate();
  const [role, setRole] = useState<string | number>("活动公司");
  const [sending, setSending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const sendCode = async () => {
    setSending(true);
    await new Promise((r) => setTimeout(r, 500));
    setSending(false);
    setCooldown(60);
    const t = setInterval(() => {
      setCooldown((v) => {
        if (v <= 1) { clearInterval(t); return 0; }
        return v - 1;
      });
    }, 1000);
    message.success("验证码已发送（Demo：直接使用 123456）");
  };

  const onFinish = async () => {
    message.success(`欢迎回来，${role} 用户`);
    nav({ to: "/agent" });
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "grid",
        gridTemplateColumns: "1.1fr 1fr",
        background: "#F5F6FA",
      }}
    >
      <div
        style={{
          background: "linear-gradient(135deg, #1B1550, #4B34D1 55%, #6E59F5)",
          color: "#fff",
          padding: "80px 60px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
        }}
      >
        <Space size={12}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 18 }}>
            演
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>演立方</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,.7)" }}>AI 商演成交平台 · 客户端</div>
          </div>
        </Space>

        <div>
          <Typography.Title style={{ color: "#fff", fontSize: 40, lineHeight: 1.2, margin: 0, fontWeight: 800 }}>
            一句话，
            <br />
            拿到你要的商演方案。
          </Typography.Title>
          <Typography.Paragraph style={{ color: "rgba(255,255,255,.75)", fontSize: 15, marginTop: 16, maxWidth: 420 }}>
            AI 商演经纪人已服务字节跳动、美团、蔚来汽车等 800+ 家企业客户，帮助你把模糊需求快速转化为完成的成交。
          </Typography.Paragraph>
        </div>

        <div style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>© 演立方 · PRD V3.3.3 · 前端原型 Demo</div>
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 40 }}>
        <Card style={{ width: 420, borderRadius: 16 }} styles={{ body: { padding: 36 } }}>
          <Typography.Title level={3} style={{ margin: 0 }}>
            登录 演立方
          </Typography.Title>
          <Typography.Text type="secondary">选择你的企业身份，开启 AI 商演经纪服务</Typography.Text>

          <div style={{ marginTop: 24 }}>
            <Segmented
              block
              options={["活动公司", "企业客户"]}
              value={role}
              onChange={setRole}
            />
          </div>

          <Form layout="vertical" style={{ marginTop: 24 }} onFinish={onFinish}>
            <Form.Item label="手机号" name="phone" initialValue="13800002091" rules={[{ required: true, message: "请输入手机号" }]}>
              <Input size="large" prefix={<MobileOutlined />} placeholder="请输入 11 位手机号" maxLength={11} />
            </Form.Item>
            <Form.Item label="短信验证码" required>
              <Space.Compact style={{ width: "100%" }}>
                <Input size="large" prefix={<SafetyCertificateOutlined />} placeholder="6 位验证码" defaultValue="123456" />
                <Button size="large" onClick={sendCode} loading={sending} disabled={cooldown > 0}>
                  {cooldown > 0 ? `${cooldown}s 后重发` : "发送验证码"}
                </Button>
              </Space.Compact>
            </Form.Item>
            <Button type="primary" htmlType="submit" size="large" block style={{ height: 46, fontSize: 15, marginTop: 8 }}>
              进入 演立方
            </Button>
          </Form>

          <div style={{ marginTop: 16, textAlign: "center", fontSize: 12, color: "#8B92A8" }}>
            登录即代表同意《服务协议》与《隐私政策》
          </div>
        </Card>
      </div>
    </div>
  );
}