import { createFileRoute, Link } from "@tanstack/react-router";
import { Button, Card, Space, Typography } from "antd";
import { ArrowRightOutlined, RobotFilled, ThunderboltFilled } from "@ant-design/icons";

export const Route = createFileRoute("/")({
  component: LandingSwitcher,
});

function LandingSwitcher() {
  return (
    <div
      style={{
        minHeight: "100vh",
        background:
          "radial-gradient(1200px 500px at 20% 0%, rgba(110,89,245,.18), transparent), radial-gradient(900px 500px at 90% 30%, rgba(0,185,107,.10), transparent), #0F1222",
        color: "#fff",
        padding: "80px 40px",
      }}
    >
      <div style={{ maxWidth: 1120, margin: "0 auto" }}>
        <Space size={12}>
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              background: "linear-gradient(135deg, #6E59F5, #4B34D1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 18,
              fontWeight: 800,
            }}
          >
            演
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>演立方</div>
            <div style={{ fontSize: 12, color: "#8B92A8" }}>AI 商演成交平台 · 前端原型 V3.3.3</div>
          </div>
        </Space>

        <div style={{ marginTop: 60, maxWidth: 780 }}>
          <Typography.Title style={{ color: "#fff", fontSize: 44, fontWeight: 800, lineHeight: 1.15, margin: 0 }}>
            让每一场商演，
            <br />
            都从「一句话」开始成交。
          </Typography.Title>
          <Typography.Paragraph style={{ color: "#B5B9C9", fontSize: 16, marginTop: 20 }}>
            演立方是面向企业客户和内部运营的 AI 商演经纪平台。客户端用一句话表达需求，运营端在 AI 作战台里高效撮合成交。
          </Typography.Paragraph>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20, marginTop: 60 }}>
          <PortalCard
            tone="#6E59F5"
            icon={<RobotFilled />}
            title="frontend-agent"
            zhTitle="客户端 · AI 商演经纪人"
            desc="活动公司 / 企业客户 PC Web。一句话描述需求，AI 立刻推荐方案与报价。"
            features={["AI 需求助手对话", "方案发现与对比", "多版本报价与追踪"]}
            cta="进入客户端"
            to="/agent"
          />
          <PortalCard
            tone="#00B96B"
            icon={<ThunderboltFilled />}
            title="frontend-supplier"
            zhTitle="运营端 · AI 销售作战台"
            desc="内部运营与商演供应商工作台。四栏工作流，AI 预生成方案，成交效率提升 3 倍。"
            features={["商机队列 + 客户需求", "AI 方案 A/B/C 生成", "跟进中心与话术推荐"]}
            cta="进入作战台"
            to="/supplier"
          />
          <PortalCard
            tone="#FA8C16"
            icon={<RobotFilled />}
            title="miniprogram"
            zhTitle="移动端 · 活动公司小程序"
            desc="任务驱动首页 + AI 经纪人对话，5 Tab 对齐微信小程序，可切到手机预览查看。"
            features={["首页 · AI 输入 + 场景快捷", "找方案 · SKU 浏览筛选", "提需求 · 双 Tab 对话"]}
            cta="进入移动端"
            to="/m"
          />
          <PortalCard
            tone="#4B34D1"
            icon={<ThunderboltFilled />}
            title="admin-console"
            zhTitle="平台端 · Admin 治理后台"
            desc="SKU、艺人、经纪公司、AI 反馈与权限的中枢。为客户端与作战台提供数据源与治理能力。"
            features={["平台大盘 · GMV / 漏斗 / AI", "SKU 库 · 三档模板治理", "AI 反馈 · SKU 命中率热力"]}
            cta="进入平台端"
            to="/admin"
          />
        </div>

        <div style={{ marginTop: 80, color: "#5B6178", fontSize: 12 }}>
          © 演立方 · 本项目为按 PRD V3.3.3 交付的前端原型，Mock 数据 + 模拟 AI 流式对话，暂未接入后端。
        </div>
      </div>
    </div>
  );
}

function PortalCard({
  tone,
  icon,
  title,
  zhTitle,
  desc,
  features,
  cta,
  to,
}: {
  tone: string;
  icon: React.ReactNode;
  title: string;
  zhTitle: string;
  desc: string;
  features: string[];
  cta: string;
  to: string;
}) {
  return (
    <Card
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 20,
        color: "#fff",
      }}
      styles={{ body: { padding: 32 } }}
    >
      <div
        style={{
          width: 52,
          height: 52,
          borderRadius: 14,
          background: `${tone}22`,
          color: tone,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 22,
        }}
      >
        {icon}
      </div>
      <div style={{ marginTop: 20, fontSize: 12, color: "#8B92A8", letterSpacing: 1 }}>{title.toUpperCase()}</div>
      <div style={{ fontSize: 24, fontWeight: 700, color: "#fff", marginTop: 4 }}>{zhTitle}</div>
      <div style={{ marginTop: 12, color: "#B5B9C9", lineHeight: 1.7 }}>{desc}</div>
      <ul style={{ marginTop: 16, paddingLeft: 18, color: "#B5B9C9", lineHeight: 2 }}>
        {features.map((f) => (
          <li key={f}>{f}</li>
        ))}
      </ul>
      <Link to={to as never}>
        <Button
          type="primary"
          size="large"
          style={{ background: tone, borderColor: tone, marginTop: 20 }}
          icon={<ArrowRightOutlined />}
          iconPosition="end"
        >
          {cta}
        </Button>
      </Link>
    </Card>
  );
}
