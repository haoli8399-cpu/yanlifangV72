import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { Card, Col, Row, Space, Typography, Empty, Button, message as antdMessage } from "antd";
import { useEffect, useMemo, useState } from "react";
import { AIChatPanel } from "../shared/components/AIChatPanel";
import { SolutionCard } from "../shared/components/SolutionCard";
import { seedChatMessages, solutions } from "../shared/mock/data";
import { useAIChat } from "../shared/hooks/useAIChat";
import { RequirementExtractPanel } from "../shared/components/RequirementExtractPanel";
import { MinimalRequirementForm, type MinimalRequirementValue } from "../shared/components/MinimalRequirementForm";
import type { Opportunity } from "../shared/types";
import { z } from "zod";

const searchSchema = z.object({ q: z.string().optional() });

export const Route = createFileRoute("/agent/assistant")({
  component: AssistantPage,
  validateSearch: (search) => searchSchema.parse(search),
});

function AssistantPage() {
  const nav = useNavigate();
  const { q } = useSearch({ from: "/agent/assistant" });
  const { messages, loading, send, recommended } = useAIChat(seedChatMessages);
  const [autoSent, setAutoSent] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  useEffect(() => {
    if (q && !autoSent) {
      setAutoSent(true);
      send(q);
    }
  }, [q, autoSent, send]);

  const currentSuggestions = messages[messages.length - 1]?.suggestions;
  const userTurns = messages.filter((m) => m.role === "user").length;

  // Build a synthetic opportunity from conversation for the extraction panel
  const syntheticOpp = useMemo<Opportunity>(() => {
    const userText = messages.filter((m) => m.role === "user").map((m) => m.content).join(" ");
    const extracted: string[] = [];
    const missing: string[] = [];
    let match = 40;
    if (/(年会|团建|发布会|商场|答谢)/.test(userText)) { extracted.push("活动类型 已识别"); match += 15; } else missing.push("活动类型");
    const headMatch = userText.match(/(\d{2,4})\s*(人|位)/);
    if (headMatch) { extracted.push(`人数：约${headMatch[1]}人`); match += 15; } else missing.push("人数规模");
    if (/(预算|万|w)/i.test(userText)) { extracted.push("预算范围 已识别"); match += 15; } else missing.push("预算范围");
    if (/(月|日|号|周)/.test(userText)) { extracted.push("时间 已识别"); match += 10; } else missing.push("活动时间");
    return {
      id: "syn",
      code: "OPP-DRAFT",
      customer: { id: "me", companyName: "字节跳动", contactName: "王雅琳", contactTitle: "行政总监", phone: "138****2091", industry: "互联网", avatarColor: "#6E59F5" },
      event: { type: "—", scene: "—", date: "—", location: "—", headcount: 0, budget: 0, durationMinutes: 0 },
      status: "新需求",
      requestStatus: "新需求",
      priority: "中",
      createdAt: new Date().toISOString(),
      lastFollowUpAt: new Date().toISOString(),
      aiExtracted: extracted.length ? extracted : ["等待你的第一条需求描述"],
      aiMissing: missing,
      matchScore: Math.min(100, match),
      rawRequirement: userText,
      ownerName: "AI 商演经纪人",
    };
  }, [messages]);

  // Fallback rule: after 3 user turns, if still missing critical fields, show minimal form
  const showFallbackForm = userTurns >= 3 && syntheticOpp.aiMissing.length > 0 && !formSubmitted;

  const handleFormSubmit = (v: MinimalRequirementValue) => {
    setFormSubmitted(true);
    const summary = `活动类型：${v.eventType}，人数：${v.headcount}人，预算：${v.budget}万，日期：${v.date.format("YYYY-MM-DD")}`;
    antdMessage.success("已按表单信息为你匹配方案");
    send(summary);
  };

  const handleConfirm = () => {
    setConfirmed(true);
    antdMessage.success("已确认需求信息，AI 开始匹配方案");
  };

  return (
    <div style={{ maxWidth: 1440, margin: "0 auto" }}>
      <Typography.Title level={3} style={{ margin: 0 }}>
        AI 需求助手
      </Typography.Title>
      <Typography.Text type="secondary">
        用中文自然语言描述需求，AI 会追问、抽取字段并推荐方案。追问最多 3 轮，之后会切换到最简表单。
      </Typography.Text>

      <Row gutter={16} style={{ marginTop: 16 }}>
        <Col xs={24} lg={14}>
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            <Card
              styles={{ body: { padding: 0, height: showFallbackForm ? 420 : 660 } }}
              style={{ borderRadius: 12, overflow: "hidden" }}
            >
              <AIChatPanel
                messages={messages}
                loading={loading}
                onSend={send}
                suggestions={currentSuggestions}
                onPickSuggestion={send}
              />
            </Card>
            {showFallbackForm && <MinimalRequirementForm onSubmit={handleFormSubmit} />}
          </Space>
        </Col>

        <Col xs={24} lg={10}>
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            <RequirementExtractPanel
              opportunity={syntheticOpp}
              editable={userTurns > 0}
              confirmed={confirmed}
              onConfirm={handleConfirm}
            />

            <Card
              title={<Typography.Text strong>AI 推荐方案</Typography.Text>}
              styles={{ body: { padding: 16, maxHeight: 380, overflowY: "auto" } }}
            >
              {recommended && recommended.length > 0 ? (
                <Space direction="vertical" size={12} style={{ width: "100%" }}>
                  {recommended.map((s, i) => (
                    <SolutionCard
                      key={s.id}
                      solution={s}
                      highlight={i === 1}
                      onGetQuote={() => nav({ to: "/agent/quotations/$id", params: { id: "q1" } })}
                    />
                  ))}
                </Space>
              ) : (
                <Empty
                  description={
                    <>
                      <div>还没有推荐方案</div>
                      <div style={{ fontSize: 12, color: "#8B92A8", marginTop: 6 }}>
                        补充活动时间与预算，AI 会给出 3 套推荐
                      </div>
                    </>
                  }
                >
                  <Button type="primary" onClick={() => send("公司300人年会，预算25万，1月中旬")}>
                    用示例需求试一次
                  </Button>
                </Empty>
              )}
            </Card>
          </Space>
        </Col>
      </Row>

      {/* Fallback showcase when nothing recommended yet */}
      {(!recommended || recommended.length === 0) && (
        <>
          <Typography.Title level={5} style={{ marginTop: 24 }}>
            或直接浏览热门方案
          </Typography.Title>
          <Row gutter={16}>
            {solutions.slice(0, 3).map((s, i) => (
              <Col key={s.id} xs={24} md={8}>
                <SolutionCard solution={s} highlight={i === 1} onGetQuote={() => nav({ to: "/agent/quotations/$id", params: { id: "q1" } })} />
              </Col>
            ))}
          </Row>
        </>
      )}
    </div>
  );
}