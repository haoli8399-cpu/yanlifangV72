import { Avatar, Button, Empty, Input, Space, Typography } from "antd";
import { RobotFilled, SendOutlined, UserOutlined } from "@ant-design/icons";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import type { ChatMessage } from "../types";
import { ConfidenceTag } from "./StatusTag";

interface Props {
  messages: ChatMessage[];
  onSend: (text: string) => void;
  loading?: boolean;
  placeholder?: string;
  suggestions?: string[];
  onPickSuggestion?: (s: string) => void;
  emptyHint?: string;
  compact?: boolean;
}

export function AIChatPanel({
  messages,
  onSend,
  loading,
  placeholder = "描述你的活动需求，AI 会为你匹配方案...",
  suggestions,
  onPickSuggestion,
  emptyHint,
  compact,
}: Props) {
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = () => {
    const t = input.trim();
    if (!t || loading) return;
    onSend(t);
    setInput("");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", minHeight: 0 }}>
      <div
        ref={scrollRef}
        style={{ flex: 1, overflowY: "auto", padding: compact ? 12 : 24, background: "#FAFBFD" }}
      >
        {messages.length === 0 ? (
          <Empty description={emptyHint ?? "开始你的第一个 AI 需求对话"} />
        ) : (
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            {messages.map((m) => (
              <MessageBubble key={m.id} msg={m} onPickSuggestion={onPickSuggestion} />
            ))}
            {loading && <ThinkingBubble />}
          </Space>
        )}
      </div>

      {suggestions && suggestions.length > 0 && !loading && (
        <div style={{ padding: "8px 16px", borderTop: "1px solid #EEF0F5", background: "#fff" }}>
          <Space wrap size={8}>
            {suggestions.map((s) => (
              <Button
                key={s}
                size="small"
                onClick={() => onPickSuggestion?.(s)}
                style={{ borderRadius: 999, background: "#F4F1FF", borderColor: "#DED4FF", color: "#4B34D1" }}
              >
                {s}
              </Button>
            ))}
          </Space>
        </div>
      )}

      <div style={{ padding: 16, borderTop: "1px solid #EEF0F5", background: "#fff" }}>
        <Input.TextArea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={placeholder}
          autoSize={{ minRows: 2, maxRows: 5 }}
          onPressEnter={(e) => {
            if (!e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          style={{ borderRadius: 10, resize: "none" }}
          disabled={loading}
        />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            Enter 发送，Shift + Enter 换行 · AI 建议仅供参考，最终由你决策
          </Typography.Text>
          <Button type="primary" icon={<SendOutlined />} onClick={send} loading={loading}>
            发送
          </Button>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ msg, onPickSuggestion }: { msg: ChatMessage; onPickSuggestion?: (s: string) => void }) {
  const isUser = msg.role === "user";
  return (
    <div style={{ display: "flex", gap: 12, flexDirection: isUser ? "row-reverse" : "row" }}>
      <Avatar
        icon={isUser ? <UserOutlined /> : <RobotFilled />}
        style={{ background: isUser ? "#0F1222" : "#6E59F5", flexShrink: 0 }}
      />
      <div style={{ maxWidth: "78%" }}>
        <div
          style={{
            background: isUser ? "#0F1222" : "#fff",
            color: isUser ? "#fff" : "#0F1222",
            padding: "12px 16px",
            borderRadius: 12,
            border: isUser ? "none" : "1px solid #EEF0F5",
            boxShadow: isUser ? "none" : "0 2px 8px rgba(15,18,34,0.04)",
            fontSize: 14,
            lineHeight: 1.7,
          }}
        >
          <div className="ai-markdown">
            <ReactMarkdown>{msg.content || (msg.streaming ? "…" : "")}</ReactMarkdown>
          </div>
          {msg.streaming && <span style={{ color: "#8B92A8" }}>▍</span>}
        </div>
        {!isUser && msg.confidence && !msg.streaming && (
          <div style={{ marginTop: 6 }}>
            <ConfidenceTag level={msg.confidence} />
          </div>
        )}
        {!isUser && msg.suggestions && msg.suggestions.length > 0 && !msg.streaming && (
          <Space wrap size={6} style={{ marginTop: 8 }}>
            {msg.suggestions.map((s) => (
              <Button key={s} size="small" onClick={() => onPickSuggestion?.(s)} style={{ borderRadius: 999 }}>
                {s}
              </Button>
            ))}
          </Space>
        )}
      </div>
    </div>
  );
}

function ThinkingBubble() {
  return (
    <div style={{ display: "flex", gap: 12 }}>
      <Avatar icon={<RobotFilled />} style={{ background: "#6E59F5" }} />
      <div
        style={{
          background: "#fff",
          padding: "12px 16px",
          borderRadius: 12,
          border: "1px solid #EEF0F5",
          fontSize: 13,
          color: "#5B6178",
        }}
      >
        <span className="ai-thinking-dot" />
        <span className="ai-thinking-dot" />
        <span className="ai-thinking-dot" />
        &nbsp; AI 正在思考...
      </div>
    </div>
  );
}