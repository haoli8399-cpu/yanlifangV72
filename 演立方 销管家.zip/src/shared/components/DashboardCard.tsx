import { Card, Space, Typography } from "antd";
import { ArrowDownOutlined, ArrowUpOutlined } from "@ant-design/icons";
import type { DashboardMetric } from "../types";

const toneMap: Record<string, string> = {
  primary: "#6E59F5",
  success: "#00B96B",
  warning: "#FA8C16",
  info: "#1677FF",
};

export function DashboardCard({ metric }: { metric: DashboardMetric }) {
  const color = toneMap[metric.tone];
  const Arrow = metric.trend === "up" ? ArrowUpOutlined : metric.trend === "down" ? ArrowDownOutlined : null;
  return (
    <Card styles={{ body: { padding: 18 } }} style={{ borderRadius: 12, borderColor: "#E5E7EF" }}>
      <Space direction="vertical" size={6} style={{ width: "100%" }}>
        <Typography.Text type="secondary" style={{ fontSize: 13 }}>
          {metric.label}
        </Typography.Text>
        <Typography.Title level={2} style={{ margin: 0, color, fontVariantNumeric: "tabular-nums" }}>
          {metric.value}
        </Typography.Title>
        <Typography.Text style={{ color: metric.trend === "down" ? "#F5222D" : "#00B96B", fontSize: 12 }}>
          {Arrow ? <Arrow /> : null} {metric.delta} · 环比昨日
        </Typography.Text>
      </Space>
    </Card>
  );
}