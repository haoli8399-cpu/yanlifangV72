import { Avatar, Button, Space, Tooltip, Typography } from "antd";
import { HolderOutlined, PushpinFilled, PushpinOutlined } from "@ant-design/icons";
import type { Opportunity } from "../types";
import { PriorityTag, StatusTag } from "./StatusTag";
import { relativeTime, wan } from "./formatters";
import { computePriority, priorityLevel } from "../utils/opportunityPriority";

interface Props {
  opportunity: Opportunity;
  active?: boolean;
  onClick?: () => void;
  pinned?: boolean;
  onPin?: () => void;
  dragHandleProps?: React.HTMLAttributes<HTMLSpanElement>;
  dragging?: boolean;
  showPriorityScore?: boolean;
}

export function OpportunityCard({
  opportunity: o,
  active,
  onClick,
  pinned,
  onPin,
  dragHandleProps,
  dragging,
  showPriorityScore,
}: Props) {
  const stop = (e: React.MouseEvent) => e.stopPropagation();
  const priority = showPriorityScore ? computePriority(o) : null;
  const level = priority ? priorityLevel(priority.score) : null;
  const partsText = priority
    ? priority.parts.map((p) => `${p.label} ${p.value >= 0 ? "+" : ""}${p.value}`).join(" · ")
    : "";
  return (
    <div
      onClick={onClick}
      style={{
        cursor: "pointer",
        padding: 14,
        borderRadius: 10,
        border: `1px solid ${active ? "#6E59F5" : pinned ? "#FFD591" : "#E5E7EF"}`,
        background: active ? "#F4F1FF" : "#fff",
        boxShadow: dragging
          ? "0 12px 24px rgba(15,18,34,0.18)"
          : active
          ? "0 4px 14px rgba(110,89,245,0.15)"
          : "none",
        transition: "all .18s ease",
        position: "relative",
        opacity: dragging ? 0.9 : 1,
      }}
    >
      {pinned && (
        <PushpinFilled
          style={{ position: "absolute", top: 8, right: 8, color: "#FA8C16", fontSize: 12 }}
        />
      )}
      <Space direction="vertical" size={8} style={{ width: "100%" }}>
        <Space style={{ width: "100%", justifyContent: "space-between" }}>
          <Space size={8}>
            {dragHandleProps && (
              <span
                {...dragHandleProps}
                onClick={stop}
                style={{ cursor: "grab", color: "#B5B9C9", fontSize: 14, display: "inline-flex", touchAction: "none" }}
                title="拖拽调整顺序"
              >
                <HolderOutlined />
              </span>
            )}
            <Avatar size={28} style={{ background: o.customer.avatarColor, fontSize: 12 }}>
              {o.customer.companyName.slice(0, 1)}
            </Avatar>
            <Typography.Text strong>{o.customer.companyName}</Typography.Text>
          </Space>
          <StatusTag status={o.status} />
        </Space>
        <Typography.Text style={{ fontSize: 13 }}>
          {o.event.type} · {o.event.headcount}人 · {o.event.date}
        </Typography.Text>
        <Space style={{ width: "100%", justifyContent: "space-between" }}>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            预算 <span style={{ color: "#0F1222", fontWeight: 600 }}>{wan(o.event.budget)}</span>
          </Typography.Text>
          <PriorityTag priority={o.priority} />
        </Space>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          最近跟进 · {relativeTime(o.lastFollowUpAt)} · {o.ownerName}
        </Typography.Text>
        {priority && level && (
          <Tooltip title={partsText}>
            <div
              onClick={stop}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                padding: "6px 10px",
                background: "#FAFBFD",
                borderRadius: 6,
                border: "1px solid #EEF0F5",
              }}
            >
              <span style={{ width: 8, height: 8, borderRadius: 4, background: level.color }} />
              <Typography.Text style={{ fontSize: 12, color: level.color, fontWeight: 600 }}>
                {level.label}
              </Typography.Text>
              <Typography.Text style={{ fontSize: 12, color: "#8B92A8" }}>
                权重 {priority.score}
              </Typography.Text>
              <div style={{ flex: 1 }} />
              {onPin && (
                <Tooltip title={pinned ? "取消置顶" : "置顶"}>
                  <Button
                    size="small"
                    type="text"
                    icon={pinned ? <PushpinFilled style={{ color: "#FA8C16" }} /> : <PushpinOutlined />}
                    onClick={onPin}
                  />
                </Tooltip>
              )}
            </div>
          </Tooltip>
        )}
        {!priority && onPin && (
          <div onClick={stop} style={{ display: "flex", justifyContent: "flex-end" }}>
            <Tooltip title={pinned ? "取消置顶" : "置顶"}>
              <Button
                size="small"
                type="text"
                icon={pinned ? <PushpinFilled style={{ color: "#FA8C16" }} /> : <PushpinOutlined />}
                onClick={onPin}
              />
            </Tooltip>
          </div>
        )}
      </Space>
    </div>
  );
}