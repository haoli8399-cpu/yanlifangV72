import { Button, Card, Divider, Space, Tag, Tooltip, Typography } from "antd";
import { CheckCircleFilled, InfoCircleOutlined, StarFilled } from "@ant-design/icons";
import type { Solution } from "../types";
import { yuan } from "./formatters";
import { ConfidenceTag } from "./StatusTag";

const tierColor: Record<string, string> = {
  经济方案: "#5B6178",
  推荐方案: "#6E59F5",
  升级方案: "#D4A017",
};

interface Props {
  solution: Solution;
  onGetQuote?: (s: Solution) => void;
  onView?: (s: Solution) => void;
  showCost?: boolean;
  highlight?: boolean;
}

export function SolutionCard({ solution: s, onGetQuote, onView, showCost, highlight }: Props) {
  return (
    <Card
      hoverable
      style={{
        borderColor: highlight ? tierColor[s.tier] : undefined,
        borderWidth: highlight ? 2 : 1,
        boxShadow: highlight ? "0 8px 24px rgba(110,89,245,0.12)" : undefined,
      }}
      styles={{ body: { padding: 20 } }}
    >
      <Space direction="vertical" size={12} style={{ width: "100%" }}>
        <Space wrap>
          <Tag color={tierColor[s.tier]} style={{ borderRadius: 4, color: "#fff", border: "none" }}>
            {s.tier}
          </Tag>
          <ConfidenceTag level={s.aiConfidence} />
          <Tag icon={<StarFilled />} color="warning" style={{ borderRadius: 4 }}>
            推荐指数 {s.recommendScore}
          </Tag>
        </Space>

        <Typography.Title level={4} style={{ margin: 0 }}>
          {s.name}
        </Typography.Title>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          SKU · {s.sku} · 时长 {s.durationMinutes} 分钟 · 适合 {s.headcountRange[0]}–{s.headcountRange[1]} 人
        </Typography.Text>

        <Typography.Paragraph type="secondary" style={{ margin: 0, fontSize: 13 }}>
          {s.description}
        </Typography.Paragraph>

        <div style={{ background: "#F5F6FA", borderRadius: 8, padding: 12, fontSize: 12 }}>
          <Typography.Text strong style={{ fontSize: 12 }}>
            艺人配置
          </Typography.Text>
          <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 4 }}>
            {s.items.map((it) => (
              <div key={it.artistId} style={{ display: "flex", justifyContent: "space-between" }}>
                <span>
                  {it.artistName} · <span style={{ color: "#8B92A8" }}>{it.category}</span>
                </span>
                <span style={{ color: "#5B6178" }}>{it.duration} 分钟</span>
              </div>
            ))}
          </div>
        </div>

        <div
          style={{
            background: "#FAF9FF",
            borderRadius: 8,
            padding: 10,
            fontSize: 12,
            border: "1px dashed #C9BEFC",
          }}
        >
          <Space size={4} align="start">
            <InfoCircleOutlined style={{ color: "#6E59F5", marginTop: 3 }} />
            <Typography.Text style={{ fontSize: 12, color: "#4B34D1" }}>
              AI 推荐理由：{s.aiReason}
            </Typography.Text>
          </Space>
        </div>

        <Divider style={{ margin: "4px 0" }} />

        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
          <div>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              方案价
            </Typography.Text>
            <div style={{ fontSize: 24, fontWeight: 700, color: tierColor[s.tier], fontVariantNumeric: "tabular-nums" }}>
              {yuan(s.price)}
            </div>
            {showCost && (
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                成本 {yuan(s.cost)} · 毛利 <span style={{ color: "#00B96B" }}>{yuan(s.grossProfit)}</span>
              </Typography.Text>
            )}
          </div>
          <Space>
            {onView && <Button onClick={() => onView(s)}>查看详情</Button>}
            {onGetQuote && (
              <Tooltip title="生成正式报价单">
                <Button type="primary" icon={<CheckCircleFilled />} onClick={() => onGetQuote(s)}>
                  获取报价
                </Button>
              </Tooltip>
            )}
          </Space>
        </div>
      </Space>
    </Card>
  );
}