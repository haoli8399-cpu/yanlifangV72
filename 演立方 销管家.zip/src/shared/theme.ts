import type { ThemeConfig } from "antd";

export const brandColors = {
  primary: "#6E59F5",
  primaryDeep: "#4B34D1",
  success: "#00B96B",
  warning: "#FA8C16",
  danger: "#F5222D",
  info: "#1677FF",
  gold: "#D4A017",
  textPrimary: "#0F1222",
  textSecondary: "#5B6178",
  textTertiary: "#8B92A8",
  bgPage: "#F5F6FA",
  bgCard: "#FFFFFF",
  border: "#E5E7EF",
};

export const statusColorMap: Record<string, string> = {
  新需求: "blue",
  需求确认: "cyan",
  有效商机: "purple",
  已报价: "geekblue",
  沟通中: "orange",
  谈判中: "orange",
  等待客户确认: "gold",
  已成交: "green",
  已结束: "default",
  已丢单: "red",
};

export const agentTheme: ThemeConfig = {
  token: {
    colorPrimary: brandColors.primary,
    colorInfo: brandColors.info,
    colorSuccess: brandColors.success,
    colorWarning: brandColors.warning,
    colorError: brandColors.danger,
    colorTextBase: brandColors.textPrimary,
    colorBgLayout: brandColors.bgPage,
    borderRadius: 8,
    fontFamily:
      '"PingFang SC", "Microsoft YaHei", "Noto Sans SC", -apple-system, "Segoe UI", Roboto, Inter, sans-serif',
    fontSize: 14,
    wireframe: false,
  },
  components: {
    Button: { borderRadius: 8, controlHeight: 40 },
    Card: { borderRadiusLG: 12 },
    Input: { borderRadius: 8, controlHeight: 40 },
    Select: { borderRadius: 8, controlHeight: 40 },
    Tag: { borderRadiusSM: 4 },
    Menu: { itemBorderRadius: 8 },
  },
};

export const supplierTheme: ThemeConfig = {
  ...agentTheme,
  token: {
    ...agentTheme.token,
    colorBgLayout: "#0F1222",
    colorPrimary: brandColors.primary,
  },
  components: {
    ...agentTheme.components,
  },
};