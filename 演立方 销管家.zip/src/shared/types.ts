export type OpportunityStatus =
  | "新需求"
  | "有效商机"
  | "已报价"
  | "谈判中"
  | "等待客户确认"
  | "已成交"
  | "已丢单";

export type RequestStatus =
  | "新需求"
  | "需求确认"
  | "已报价"
  | "沟通中"
  | "已成交"
  | "已结束";

export type Priority = "高" | "中" | "低";

export interface Customer {
  id: string;
  companyName: string;
  contactName: string;
  contactTitle: string;
  phone: string;
  industry: string;
  avatarColor: string;
}

export interface EventInfo {
  type: string;
  scene: string;
  date: string;
  location: string;
  headcount: number;
  budget: number;
  durationMinutes: number;
}

export interface Artist {
  id: string;
  name: string;
  category: string;
  tags: string[];
  basePrice: number;
  rating: number;
  bio: string;
}

export interface SolutionItem {
  artistId: string;
  artistName: string;
  category: string;
  duration: number;
  price: number;
  cost: number;
}

export type SolutionTier = "经济方案" | "推荐方案" | "升级方案";

export interface Solution {
  id: string;
  tier: SolutionTier;
  name: string;
  sku: string;
  scene: string;
  applicableScenes: string[];
  headcountRange: [number, number];
  durationMinutes: number;
  items: SolutionItem[];
  price: number;
  cost: number;
  grossProfit: number;
  recommendScore: number;
  aiConfidence: "高" | "中" | "低";
  aiReason: string;
  description: string;
}

export interface Opportunity {
  id: string;
  code: string;
  customer: Customer;
  event: EventInfo;
  status: OpportunityStatus;
  requestStatus: RequestStatus;
  priority: Priority;
  createdAt: string;
  lastFollowUpAt: string;
  aiExtracted: string[];
  aiMissing: string[];
  matchScore: number;
  rawRequirement: string;
  ownerName: string;
}

export interface QuotationVersion {
  version: string;
  createdAt: string;
  editor: string;
  solutionId: string;
  solutionName: string;
  items: SolutionItem[];
  totalPrice: number;
  totalCost: number;
  discount: number;
  finalPrice: number;
  changeNote: string;
  changes: string[];
}

export interface Quotation {
  id: string;
  code: string;
  opportunityId: string;
  customerName: string;
  eventType: string;
  currentVersion: string;
  versions: QuotationVersion[];
  status: "草稿" | "已发送" | "客户确认中" | "已成交" | "已作废";
  validUntil?: string;
  sentAt?: string;
  readAt?: string;
  customerConfirmStatus?: "未回复" | "已阅" | "已确认" | "已拒绝";
  voidReason?: string;
}

export interface FollowUp {
  id: string;
  opportunityId: string;
  time: string;
  actor: "客户" | "运营" | "AI";
  channel: "电话" | "微信" | "邮件" | "系统";
  content: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: string;
  streaming?: boolean;
  confidence?: "高" | "中" | "低";
  suggestions?: string[];
}

export interface DashboardMetric {
  label: string;
  value: string;
  delta: string;
  trend: "up" | "down" | "flat";
  tone: "primary" | "success" | "warning" | "info";
}